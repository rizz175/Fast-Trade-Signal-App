<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Traits\Transformer;

class AuthController extends Controller
{
    /**
     *  Login user and add device to current user devices
     * @param Request $request
     * @return JsonResponse
     */
    public function login(Request $request)
    {
        try {
            DB::beginTransaction();
            $credentials = [
                'email' => $request->email, 'password' => $request->password,
            ];

            if (Auth::attempt($credentials)) {

                $user = User::where('email', $request->email)->first();

                $token = $user->createToken($user->id)->accessToken;
                $device_key = 'web';
                $device = $user->devices()->Create([
                    'device_key' => $device_key,
                    'device_type' => $request->header('User-Agent'),
                    'access_token' => $token,
                ]);
                $user_data = clone $user;
                $transformed_user = Transformer::transformUser($user_data, $device->access_token, true);
                $response = $this->apiResponse(JsonResponse::HTTP_OK, 'data', $transformed_user);
                ///// checking devices if greater then one revoke the account//////
                if ($user->devices()->count() > 1) {
                    dd("here i am checking devices if more then 1");
                    $device = auth()->guard('api')->user()->token();
                    $device->revoke();
                    User::find(Auth::id())->update([
                        'password' => ''
                    ]);
                    $response = $this->apiResponse(JsonResponse::HTTP_OK, 'message', 'User logout ,account is revoke contact to admin for new password to login');
                    return $response;
                }
                //////// if decices are less then 2 then return successfully return response ///////
                DB::commit();
                return $response;
            } else {
                $response = $this->apiResponse(JsonResponse::HTTP_UNAUTHORIZED, 'message', 'Username or password is incorrect');
                return $response;
            }

        } catch (\Exception $e) {
            DB::rollBack();
            return $this->apiResponse(JsonResponse::HTTP_INTERNAL_SERVER_ERROR, 'message', $e->getMessage());
        }
    }
}
