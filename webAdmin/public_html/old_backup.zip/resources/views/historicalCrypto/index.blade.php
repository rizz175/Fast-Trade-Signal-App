@extends('layout')

@section('title')
    Historical Crypto Signals
@endsection

@section('content')

<div class="card">
    <table class="table datatable-save-state">
        <thead>
            <tr>
                <th>#</th>
                <th>Symbol</th>
                <th>Type</th>
                <th>TP</th>
                <th>SL</th>
                <th>LOT</th>
                <th>Profit</th>
                <th>Action</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach (App\Models\Crypto::onlyTrashed()->get() as $key => $crypto)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$crypto->symbol}}</td>
                <td>{{$crypto->type}}</td>
                <td>{{$crypto->tp}}</td>
                <td>{{$crypto->sl}}</td>
                <td>{{$crypto->lot}}</td>
                <td>{{$crypto->profit}}</td>
                <td>
                    <button data-toggle="modal" data-target="#edit_modal" symbol="{{$crypto->symbol}}"
                    id="{{$crypto->id}}" type="{{$crypto->type}}" tp="{{$crypto->tp}}" sl="{{$crypto->sl}}" lot="{{$crypto->lot}}" profit="{{$crypto->profit}}"
                     class="edit-btn btn btn-primary">Edit</button>
                </td>
                <td>
                    <form action="{{route("deleteHistoricalCrypto",$crypto->id)}}" method="POST">
                        {{-- @method('DELETE') --}}
                        @csrf
                    <button type="submit"  class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
       {{-- modal for historical forex signals --}}
<div id="edit_modal" class="modal fade">
    <div class="modal-dialog">
        <form id="updateForm" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabel">Update Crypto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="symbol">Symbol</label>
                        <input class="form-control" type="text" id="symbol" name="symbol"  placeholder="Enter symbol" required>
                    </div> 
                    <div class="form-group">
                        <label for="type">Type</label>
                        <input class="form-control" type="text" id="type" name="type" placeholder="Enter type" step="0.01" required>
                    </div>
                     <div class="form-group">
                        <label for="tp">TP</label>
                        <input class="form-control" type="number" id="tp" name="tp" placeholder="Enter tp" step="0.01" required>
                    </div> 
                    <div class="form-group">
                        <label for="tp">SL</label>
                        <input class="form-control" type="number" id="sl" name="sl" placeholder="Enter sl" step="0.01" required>
                    </div>  
                    <div class="form-group">
                        <label for="tp">LOT</label>
                        <input class="form-control" type="number" id="lot" name="lot" placeholder="Enter lot" step="0.01" required>
                    </div> 
                    <div class="form-group">
                        <label for="profit">Profit</label>
                        <input class="form-control" type="number" id="profit" name="profit" placeholder="Enter profit"  required>
                    </div>
        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
    $(document).ready(function(){
        $('.edit-btn').click(function(){

            let id = $(this).attr('id');
            let symbol = $(this).attr('symbol');
            let type = $(this).attr('type');
            let tp = $(this).attr('tp');
            let sl = $(this).attr('sl');
            let lot = $(this).attr('lot');
            let profit = $(this).attr('profit');
        
            $('#id').val(id);
            $('#symbol').val(symbol);
            $('#type').val(type);
            $('#tp').val(tp);
            $('#sl').val(sl);
            $('#lot').val(lot);
            $('#profit').val(profit);

            $('#updateForm').attr('action','{{route('updatehistoricalcrypto','')}}' +'/'+id);
        });
    });
</script>
@endsection