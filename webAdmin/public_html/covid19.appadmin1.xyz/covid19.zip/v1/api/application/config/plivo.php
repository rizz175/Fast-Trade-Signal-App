<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
* Config for the Plivo library
*/

$config['AUTH_ID'] = '';

$config['AUTH_TOKEN'] = '';

$config['API_VERSION'] = 'v1';

$config['END_POINT'] = 'https://api.plivo.com';