<?php defined('BASEPATH') OR exit('No direct script access allowed');

//smtp
$config['protocol'] =  'smtp';
$config['smtp_host'] =  'smtp.sendgrid.net';
$config['smtp_port'] =  587;
$config['smtp_user'] =  'apikey';
$config['smtp_pass'] =  '';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";
$config['wordwrap'] = TRUE;

    